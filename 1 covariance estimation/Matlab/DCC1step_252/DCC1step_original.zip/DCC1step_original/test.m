addpath(genpath('DCC')); % import DCC-GARCH functions for 1-steap ahead prediction

returns = readtable('DJ30_1990_2016_demeaned_scaled.csv', 'ReadVariableNames', true);

% extract data
ncol = size(returns, 2);
dates = returns{:, 1};
marketData = returns{:, ncol};
stockData = returns(:, 2:(ncol-1));

dccData = stockData{1:300, 1:2};
[mu, Sigma] = DCC1step(dccData);